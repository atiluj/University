int bar = 42;
short dead[15];
