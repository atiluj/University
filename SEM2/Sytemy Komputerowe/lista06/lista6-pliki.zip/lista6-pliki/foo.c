long foo = 19;
char code[17];
