//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;

public class SpisZmarlych {
    JFrame mainFrame;
    ArrayList<Ozdrowiali> kolekcja;
    JButton wroc;
    JTable tablica_zmarlych;

    SpisZmarlych(final ArrayList<Pacjent> kolekcja) throws FileNotFoundException {
        mainFrame = new JFrame();
        mainFrame.setLayout(null);
        //Ustawienie głównego okienka zawsze w centrum
        //pobranie szerokości i wysokości ekranu użytkownika
        int szer_ekranu = Toolkit.getDefaultToolkit().getScreenSize().width;
        int wys_ekranu = Toolkit.getDefaultToolkit().getScreenSize().height;
        //ustawienie rozmiaru okienka głównego
        mainFrame.setSize(szer_ekranu / 2, wys_ekranu * 4 / 7);
        //ustalenie rozmiaru okienka głównego
        int szer_okienka = mainFrame.getSize().width;
        int wys_okienka = mainFrame.getSize().height;
        //ustawienie okienka głównego na ekranie
        mainFrame.setLocation((szer_ekranu - szer_okienka) / 2, (wys_ekranu - wys_okienka) / 2);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //this.kolekcja = kolekcja;

        //--------------TABELA DANYCH -- ZARAZENI
        ArrayList <Zmarli> lista_zmarlych = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader("zmarli.txt"));
        try {
            lista_zmarlych = Zmarli.OdczytajZPliku(reader);
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //System.out.println(lista_zmarlych);

        String[] naglowki = {"PESEL" , "IMIE" , "NAZWISKO", "PLEC", "DATA DIAGNOZY", "DATA ZGONU"};
        String[][] dane = new String[lista_zmarlych.size()+1][6];
        dane[0][0] = "PESEL";
        dane[0][1] = "IMIE";
        dane[0][2] = "NAZWISKO";
        dane[0][3] = "PLEC";
        dane[0][4] = "DATA DIAGNOZY";
        dane[0][5] = "DATA ZGONU";

        for (int i=0; i<lista_zmarlych.size(); i++)
        {
            dane[i+1][0] = lista_zmarlych.get(i).getPesel();
            dane[i+1][1] = lista_zmarlych.get(i).getImie();
            dane[i+1][2] = lista_zmarlych.get(i).getNazwisko();
            dane[i+1][3] = lista_zmarlych.get(i).getPlec();
            dane[i+1][4] = lista_zmarlych.get(i).getDatDiag();
            dane[i+1][5] = lista_zmarlych.get(i).getDatZgon();
        }
        tablica_zmarlych = new JTable(dane,naglowki);
        tablica_zmarlych.setLocation(0,0);
        tablica_zmarlych.setSize(szer_okienka , wys_okienka - 160);
        JScrollPane sp =new JScrollPane(tablica_zmarlych);
        mainFrame.add(sp);
        mainFrame.add(tablica_zmarlych);


        //------------WRÓĆ
        wroc = new JButton("WRÓĆ");
        wroc.setLocation(szer_okienka / 12, wys_okienka * 6 / 9 + 60);
        wroc.setSize(wroc.getPreferredSize());
        wroc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainFrame.dispose();
            }
        });
        mainFrame.add(wroc);
        //------------

        mainFrame.setVisible(true);
    }
}


