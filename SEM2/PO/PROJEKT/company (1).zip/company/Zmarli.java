//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.StringTokenizer;


public class Zmarli extends Pacjent {

    String data_zgon;
    Zmarli(String imie, String nazwisko, String plec, int wiek, String pesel, String data_ur, String adres_zam, String data_zgon, String data_zdiag, String lekarz_prowa, String miejsce_lecz, String adres_pobytu, String przebieg_choroby){
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.plec = plec;
        this.wiek = wiek;
        this.pesel = pesel;
        this.data_ur = data_ur;
        this.adres_zam = adres_zam;
        this.data_zdiag = data_zdiag;
        this.lekarz_prowa = lekarz_prowa;
        this.miejsce_lecz = miejsce_lecz;
        this.adres_pobytu = adres_pobytu;
        this.przebieg_choroby = przebieg_choroby;
        this.data_zgon = data_zgon;
    }

    Zmarli(String pesel, String imie, String nazwisko, String plec, String data_zdiag, String data_zgon)
    {
        this.pesel = pesel;
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.plec = plec;
        this.data_zdiag = data_zdiag;
        this.data_zgon = data_zgon;
    }

    public String getPesel() {return pesel;}
    public String getImie() {
        return imie;
    }
    public String getNazwisko() {
        return nazwisko;
    }
    public String getPlec() {
        return plec;
    }
    public String getDatDiag() {
        return data_zdiag;
    }
    public String getDatZgon() {
        return data_zgon;
    }


    public String toString(){
        String result = "<html>DANE PACJENTA: <br/>" + "<html><br/><html/>" + "imie: " + imie
                + "<html><br/><html/>" + "nazwisko: " + nazwisko + "<html><br/><html/>" + "Plec: " + plec;
        return result;
    }

    public static ArrayList<Zmarli> OdczytajZPliku (BufferedReader plik) throws IOException {
        ArrayList <Zmarli> spis_zmarlych = new ArrayList<>();

        while(plik.ready())
        {
            String wiersz = plik.readLine();
            StringTokenizer dane = new StringTokenizer(wiersz, "|");

            String pesel = dane.nextToken();
            String imie = dane.nextToken();
            String nazwisko = dane.nextToken();
            String plec = dane.nextToken();
            String data_diag = dane.nextToken();
            String data_zgon = dane.nextToken();

            spis_zmarlych.add(new Zmarli(pesel, imie, nazwisko, plec, data_diag, data_zgon));
        }
        return spis_zmarlych;
    }
}