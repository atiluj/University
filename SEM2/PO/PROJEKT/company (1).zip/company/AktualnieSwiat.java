//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class AktualnieSwiat {
    JFrame mainFrame;
    ArrayList<Pacjent> kolekcja;
    String op = "ŚWIAT - Stan aktualny na dzień: [2020-06-03]";
    JButton pom_opis;
    JLabel opis;
    JButton zarazenia;
    JButton uzdrowienia;
    JButton zgony;
    JButton wroc;

    AktualnieSwiat(final ArrayList<Pacjent> kolekcja){
        mainFrame = new JFrame();
        mainFrame.setLayout(null);
        //Ustawienie głównego okienka zawsze w centrum
        //pobranie szerokości i wysokości ekranu użytkownika
        int szer_ekranu = Toolkit.getDefaultToolkit().getScreenSize().width;
        int wys_ekranu = Toolkit.getDefaultToolkit().getScreenSize().height;
        //ustawienie rozmiaru okienka głównego
        mainFrame.setSize(szer_ekranu/2, wys_ekranu*4/7);
        //ustalenie rozmiaru okienka głównego
        int szer_okienka = mainFrame.getSize().width;
        int wys_okienka = mainFrame.getSize().height;
        //ustawienie okienka głównego na ekranie
        mainFrame.setLocation((szer_ekranu-szer_okienka)/2, (wys_ekranu-wys_okienka)/2); //początkowo był this //zawsze na srodku
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.kolekcja = kolekcja;
//------------NAPIS GŁÓWNY

        pom_opis = new JButton(op);
        pom_opis.setSize(pom_opis.getPreferredSize());
        int wys_opis = pom_opis.getSize().height;
        int szer_opis = pom_opis.getSize().width;

        opis = new JLabel(op);
        int szer_label = (szer_okienka - szer_opis)/2;
        opis.setBounds((szer_okienka - szer_opis)/2, 60, szer_opis, wys_opis);
        opis.setSize(pom_opis.getPreferredSize());

        mainFrame.add(opis);
//-------UZDROWIENIA
        uzdrowienia = new JButton("UZDROWIEŃ - 3 973 455");
        //ustawienie idealnego rozmairu guzika
        uzdrowienia.setSize(uzdrowienia.getPreferredSize());
        int szer_guzika = uzdrowienia.getSize().width;
        int wys_guzika = uzdrowienia.getSize().height;
        //ustawienie lokalizacji - zawsze na środka
        uzdrowienia.setLocation((szer_okienka*2/3) - szer_guzika - (szer_okienka/3 - szer_guzika)/2, (wys_okienka*2)/5);
        //pomaranczowa ramka
        uzdrowienia.setBorder(BorderFactory.createLineBorder(Color.GREEN));
        mainFrame.add(uzdrowienia);
//----------ZACHOROWANIA
        zarazenia = new JButton("ZARAŻEŃ - 7 752 504");
        //ustawienie idealnego rozmairu guzika
        zarazenia.setSize(szer_guzika, wys_guzika);
        //ustawienie lokalizacji - zawsze na środka
        zarazenia.setLocation((szer_okienka/3 - szer_guzika)/2 , (wys_okienka*2)/5);
        //pomaranczowa ramka
        zarazenia.setBorder(BorderFactory.createLineBorder(Color.RED));
        mainFrame.add(zarazenia);
        //-------ZGONY
        zgony = new JButton("ZGONÓW - 428 510");
        //ustawienie idealnego rozmairu guzika
        zgony.setSize(szer_guzika, wys_guzika);
        //ustawienie lokalizacji - zawsze na środka
        zgony.setLocation(szer_okienka - szer_guzika - (szer_okienka/3 - szer_guzika)/2, (wys_okienka*2)/5);
        //pomaranczowa ramka
        zgony.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        mainFrame.add(zgony);
        //------------WRÓĆ
        wroc = new JButton("WRÓĆ");
        wroc.setLocation(szer_okienka/12, wys_okienka*6/9+60);
        wroc.setSize(wroc.getPreferredSize());
        wroc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainFrame.dispose();
            }
        });
        mainFrame.add(wroc);
        mainFrame.setVisible(true);

    }}
