//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Swiat {
    JFrame mainFrame;
    ArrayList<Pacjent> kolekcja;
    JButton wroc;
    JButton aktualnie;
    JTable statystyka_SW;

    Swiat(final ArrayList<Pacjent> kolekcja){
        mainFrame = new JFrame();
        mainFrame.setLayout(null);
        //Ustawienie głównego okienka zawsze w centrum
        //pobranie szerokości i wysokości ekranu użytkownika
        int szer_ekranu = Toolkit.getDefaultToolkit().getScreenSize().width;
        int wys_ekranu = Toolkit.getDefaultToolkit().getScreenSize().height;
        //ustawienie rozmiaru okienka głównego
        mainFrame.setSize(szer_ekranu/2, wys_ekranu*4/7);
        //ustalenie rozmiaru okienka głównego
        int szer_okienka = mainFrame.getSize().width;
        int wys_okienka = mainFrame.getSize().height;
        //ustawienie okienka głównego na ekranie
        mainFrame.setLocation((szer_ekranu-szer_okienka)/2, (wys_ekranu-wys_okienka)/2); //początkowo był this //zawsze na srodku
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.kolekcja = kolekcja;

        //--------------TABELA DANYCH POLSKA
        String dane_pl[][]={{"DATA","ZACHOROWANIA","OZDROWIENIA", "ZGONY"},
                {"2020-01-21","282","0","0"},
                {"2020-02-01","2 127","0","46"},
                {"2020-02-06","3 722","0","73"},
                {"2020-02-17","19 572","0","106"},
                {"2020-03-01","1 734","0","53"},
                {"2020-03-21","31 999","0","1 343"},
                {"2020-04-01","72 737","0","4 193"},
                {"2020-04-27","73 400","0","4 946"},
                {"2020-05-01","84 762","0","6 403"},
                {"2020-05-10","61 578","0","8 499"},
                {"2020-05-12","82 591","0","4 261"},
                {"2020-05-16","86 827","0","4 936"},
                {"2020-05-22","100 284","0","4 469"},
                {"2020-05-29","107 706","0","4 354"},
                {"2020-05-31","117 551","0","4 461"},
                {"2020-06-04","129 057","0","2 926"},
                {"2020-06-08","131 287","0","3 469"},
                {"2020-06-10","105 482","0","3 629"},
                {"2020-06-12","136 552","0","4 922"},
                {"2020- - ","","",""}
        };
        String kolumna_pl[]={"DATA","ZACHOROWANIA","OZDROWIENIA", "ZGONY"};
        statystyka_SW = new JTable(dane_pl,kolumna_pl);
        statystyka_SW.setLocation(0,0);
        statystyka_SW.setSize(szer_okienka, wys_okienka - 120);
        JScrollPane sp =new JScrollPane(statystyka_SW);
        mainFrame.add(sp);
        mainFrame.add(statystyka_SW);

        //----------AKTUALNE
        aktualnie = new JButton("AKTUALNIE");
        aktualnie.setLocation((szer_okienka*9)/12,wys_okienka*6/9+60);
        aktualnie.setSize(aktualnie.getPreferredSize());
        aktualnie.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                AktualnieSwiat a1;
                a1 = new AktualnieSwiat(kolekcja);
            }
        });
        mainFrame.add(aktualnie);

        //------------WRÓĆ
        wroc = new JButton("WRÓĆ");
        wroc.setLocation(szer_okienka/12, wys_okienka*6/9+60);
        wroc.setSize(wroc.getPreferredSize());
        wroc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainFrame.dispose();
            }
        });
        mainFrame.add(wroc);
        mainFrame.setVisible(true);
    }

}
