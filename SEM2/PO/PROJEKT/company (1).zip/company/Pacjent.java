//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

public abstract class Pacjent{
    protected String imie = "imie";
    protected String nazwisko = "nazwisko";
    protected String plec = "?";
    protected int wiek = 0;
    protected String pesel = "54463098762";
    protected String data_ur = "0000-00-00";
    protected String adres_zam = "ul. ??? ??, ??-???, ???????, ??????";
    protected String data_zdiag = "0000-00-00";
    protected String lekarz_prowa = "????  ????";
    protected String miejsce_lecz = "dom/szpital";
    protected String adres_pobytu = "ul. ??? ??, ??-???, ???????, ??????";
    protected String przebieg_choroby = "???.........";

    public String getImie(){
        return imie;
    }

    public String getNazwisko(){
        return nazwisko;
    }

    public String getPlec(){
        return plec;
    }

    public int getWiek(){
        return wiek;
    }

    public String getPesel(){
        return pesel;
    }

    public String getData_ur(){
        return data_ur;
    }

    public String getAdres_zam(){
        return adres_zam;
    }

    Pacjent(String imie, String nazwisko, String plec, int wiek, String pesel, String data_ur, String adres_zam){ //konsruktor
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.plec = plec;
        this.wiek = wiek;
        this.pesel = pesel;
        this.data_ur = data_ur;
        this.adres_zam = adres_zam;
    }

    Pacjent(){} //potrzebne do konstruktora Zarazonego
}