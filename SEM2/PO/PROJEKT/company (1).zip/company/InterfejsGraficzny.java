//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.swing.JLabel;

public class InterfejsGraficzny{
    ArrayList<Pacjent> kolekcja;
    String hello = "<html>&nbsp;&nbsp;SPIS PACJENTÓW<br/>" + "<html><br/><html/>" +
            "PANDEMIA COVID-19" + "<html><br/><html/>" +
            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2020 <html/> "; //NAPIS GŁÓWNY
    JFrame mainFrame; //glowne okienko
    JLabel invitation; //napis hello
    JButton pom_hello; //pomocnicza hello do ustaenia szerokości i wysokosći guzika
    JButton edytuj_pacjenta; //GUZIK 1 - dodaj zarażonego
    JButton spisZarazonych; //GUZIK 2 -spis zarażonych
    JButton spisWyleczonych; //GUZIK 3 -spis wyleocznych
    JButton spisZmarlych; //GUZIK 4 -spis zmarłych
    JButton statystyki; //GUZIK 5 -statystyki

    InterfejsGraficzny(final ArrayList<Pacjent> kolekcja){
        this.kolekcja = kolekcja;

        //tytuł ramki + ikona
        mainFrame = new JFrame("SPIS PACJENTÓW");
        mainFrame.setIconImage(Toolkit.getDefaultToolkit().getImage("ikona.jpg")); //ikonka czerwonego krzyża
        //ustawienie funkcji naciśniecia X (zamknie się)
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //zamiast JFrame.EXIT_IN_CLOSE można wpisać 3
        mainFrame.setLayout(null);

        //Ustawienie głównego okienka zawsze w centrum
        //pobranie szerokości i wysokości ekranu użytkownika
        int szer_ekranu = Toolkit.getDefaultToolkit().getScreenSize().width;
        int wys_ekranu = Toolkit.getDefaultToolkit().getScreenSize().height;
        //ustawienie rozmiaru okienka głównego
        mainFrame.setSize(szer_ekranu/2, wys_ekranu*4/7);
        //ustalenie rozmiaru okienka głównego
        int szer_okienka = mainFrame.getSize().width;
        int wys_okienka = mainFrame.getSize().height;
        //ustawienie okienka głównego na ekranie
        mainFrame.setLocation((szer_ekranu-szer_okienka)/2, (wys_ekranu-wys_okienka)/2); //początkowo był this //zawsze na srodku

//---------ustawienie tla
        JLabel ImageLabel = new JLabel(new ImageIcon("C:\\Users\\stale\\IdeaProjects\\ProjektPO\\src\\res\\starttlo.jpg"));
        ImageLabel.setBounds(0,0,szer_okienka,wys_okienka);
        mainFrame.add(ImageLabel);
//-------------------------------------------------------------------------------------
        //GUZIK 1 - Dodaj zarażonego
        edytuj_pacjenta = new JButton("PACJENCI");
        //ustawienie idealnego rozmairu guzika
        edytuj_pacjenta.setSize(edytuj_pacjenta.getPreferredSize());
        //pobranie wysokosci i szerokosci GUZIKA 1
        int szer_guzika1 = edytuj_pacjenta.getSize().width;
        int wys_guzika1 = edytuj_pacjenta.getSize().height;
        //ustawienie lokalizacji - zawsze na środku
        int wys = ((wys_okienka-wys_guzika1)/3);
        int szer = (szer_okienka-szer_guzika1)/2;
        edytuj_pacjenta.setLocation(szer,wys);
        //czarna ramka
        edytuj_pacjenta.setBorder(BorderFactory.createLineBorder(Color.red));
        //co się stanie po wciśnięciu guzika
        edytuj_pacjenta.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                EdytujPacjenta e1;
                e1 = new EdytujPacjenta(kolekcja);
            }
        });
        //dodanie GUZIKA 1 do okienka głównego
        mainFrame.add(edytuj_pacjenta, BorderLayout.CENTER);
//--------------------------------------------------------------------------------------------------------
        //NAPIS GŁÓWNY
        pom_hello = new JButton( "<html>&nbsp;&nbsp;SPIS PACJENTÓW<br/>" + "<html><br/><html/>" +
                "PANDEMIA COVID-19" + "<html><br/><html/>" +
                "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2020 <html/> ");
        pom_hello.setSize(pom_hello.getPreferredSize());
        pom_hello.setBorder(BorderFactory.createLineBorder(Color.pink));
        int wys_hello = pom_hello.getSize().height;
        int szer_hello = pom_hello.getSize().width;
        pom_hello.setBounds((szer_okienka - szer_hello)/2, 45, szer_hello,wys_hello);
        mainFrame.add(pom_hello, BorderLayout.CENTER);

       /* invitation = new JLabel(hello);
        int szer_label = (szer_okienka - szer_guzika1)/2 + (szer_guzika1 - szer_hello)*3 ;
        invitation.setBounds(szer_label + 6, wys_guzika1 + 11, szer_hello, wys_hello);
        invitation.setSize(pom_hello.getPreferredSize());

        mainFrame.add(invitation, BorderLayout.CENTER);*/


//---------------------------------------------------------------------------------------------------------
        //GUZIK 3 - spis wyleczonych c.d.n.
        spisWyleczonych = new JButton("SPIS WYLECZONYCH");
        //musimy tu wstawic Guzik 3 żeby setSize guzika 2 wiedział jak ma wziąc rozmiar bo my chcemy żeby był taki sam
// --------------------------------------------------------------------------------------------------------
        //GUZIK 2 -spis zarażonych
        spisZarazonych = new JButton("SPIS ZARAŻONYCH");
        //ustawienie idealnego rozmairu guzika
        spisZarazonych.setSize(spisWyleczonych.getPreferredSize());
        //pobranie wysokosci i szerokosci GUZIKA 1
        int szer_guzika2 = spisZarazonych.getSize().width;
        int wys_guzika2 = spisZarazonych.getSize().height;
        //ustawienie lokalizacji - zawsze na środka
        int wys_pom2 = wys + wys_guzika2 + 25;
        spisZarazonych.setLocation((szer_okienka-szer_guzika2)/2, wys_pom2);
        //pomaranczowa ramka
        spisZarazonych.setBorder(BorderFactory.createLineBorder(Color.RED));
        //co się stanie po wciśnięciu guzika
        spisZarazonych.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                SpisZarazonych e1;
                try {
                    e1 = new SpisZarazonych(kolekcja);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });

        //dodanie GUZIKA 2 do okienka głównego
        mainFrame.add(spisZarazonych, BorderLayout.CENTER);
//--------------------------------------------------------------------------------------------------------
        //GUZIK 3 - spis wyleczonych c.d.
        spisWyleczonych.setSize(spisWyleczonych.getPreferredSize());
        //pobranie wysokosci i szerokosci GUZIKA 1
        int szer_guzika3= spisWyleczonych.getSize().width;
        int wys_guzika3 = spisWyleczonych.getSize().height;
        //ustawienie lokalizacji - zawsze na środku
        int wys_pom3 = wys_pom2 + wys_guzika3 + 10;
        spisWyleczonych.setLocation((szer_okienka - szer_guzika3)/2, wys_pom3);
        //zielona ramka
        spisWyleczonych.setBorder(BorderFactory.createLineBorder(Color.GREEN));
        //co się stanie po wciśnięciu guzika

        spisWyleczonych.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                SpisOzdrowialych e1;
                try {
                    e1 = new SpisOzdrowialych(kolekcja);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });
        //dodanie GUZIKA 3 do okienka głównego
        mainFrame.add(spisWyleczonych, BorderLayout.CENTER);
//--------------------------------------------------------------------------------------------------------
        //GUZIK 4 - Dodaj zmarłych
        spisZmarlych = new JButton("SPIS ZMARŁYCH");
        //ustawienie idealnego rozmairu guzika
        spisZmarlych.setSize(szer_guzika3, wys_guzika3);
        //pobranie wysokosci i szerokosci GUZIKA 1
        int szer_guzika4 = spisZarazonych.getSize().width;
        int wys_guzika4 = spisZarazonych.getSize().height;
        //ustawienie lokalizacji - zawsze na środku
        int wys_pom4 = wys_pom3 + wys_guzika2 + 10;
        spisZmarlych.setLocation((szer_okienka-szer_guzika3)/2, wys_pom4);//

        //czarna ramka
        spisZmarlych.setBorder(BorderFactory.createLineBorder(Color.black));
        //co się stanie po wciśnięciu guzika
        spisZmarlych.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                SpisZmarlych e1;
                try {
                    e1 = new SpisZmarlych(kolekcja);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });
        //dodanie GUZIKA 4 do okienka głównego
        mainFrame.add(spisZmarlych, BorderLayout.CENTER);
//--------------------------------------------------------------------------------------------------------
        //GUZIK 5 - statystyki

        statystyki = new JButton("STATYSTYKI");
        //ustawienie idealnego rozmairu guzika
        statystyki.setSize(statystyki.getPreferredSize());
        //pobranie wysokosci i szerokosci GUZIKA 1
        int szer_guzika5 = statystyki.getSize().width;
        int wys_guzika5 = statystyki.getSize().height;
        //ustawienie lokalizacji - zawsze na środku
        statystyki.setLocation((szer_okienka-szer_guzika5)/2, wys_pom4 + wys_guzika5 + 20);
        //niebieska ramka
        statystyki.setBorder(BorderFactory.createLineBorder(Color.blue));
        //co się stanie po wciśnięciu guzika
        statystyki.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Statystyki s1;
                s1 = new Statystyki(kolekcja);
            }
        });
        mainFrame.add(statystyki, BorderLayout.CENTER);
//--------------------------------------------------------------------------------------------------------
        mainFrame.setVisible(true);
    }

}