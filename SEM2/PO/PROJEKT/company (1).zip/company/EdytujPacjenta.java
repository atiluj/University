//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.JLabel;

public class EdytujPacjenta {

    EdytujPacjenta(ArrayList<Pacjent> kolekcja) {
        JFrame mainFrame;
        mainFrame = new JFrame("SPIS PACJENTÓW");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setLayout(null);

        //Ustawienie głównego okienka zawsze w centrum
        //pobranie szerokości i wysokości ekranu użytkownika
        int szer_ekranu = Toolkit.getDefaultToolkit().getScreenSize().width;
        int wys_ekranu = Toolkit.getDefaultToolkit().getScreenSize().height;
        //ustawienie rozmiaru okienka głównego
        mainFrame.setSize(szer_ekranu / 2, wys_ekranu * 4 / 7);
        //ustalenie rozmiaru okienka głównego
        int szer_okienka = mainFrame.getSize().width;
        int wys_okienka = mainFrame.getSize().height;
        //ustawienie okienka głównego na ekranie
        mainFrame.setLocation((szer_ekranu - szer_okienka) / 2, (wys_ekranu - wys_okienka) / 2); //początkowo był this //zawsze na srodku

        int xStart = (szer_okienka - 250)/2;
        //----------------
        JButton dodajZarazonego = new JButton("DODAJ ZARAŻONEGO");
        //ustawienie idealnego rozmairu guzika
        dodajZarazonego.setSize(250, 30);
        int wys_guzika1 = dodajZarazonego.getSize().height;
        dodajZarazonego.setLocation(xStart, 20);
        //czerwona ramka
        dodajZarazonego.setBorder(BorderFactory.createLineBorder(Color.red));
        //co się stanie po wciśnięciu guzika
        dodajZarazonego.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                DodajZarazonego e1;
                e1 = new DodajZarazonego(kolekcja);
            }
        });
        mainFrame.add(dodajZarazonego, BorderLayout.CENTER);

        //-------------
        JButton wyszukajPacjenta = new JButton("AKTUALIZUJ STAN PACJENTA");
        //ustawienie idealnego rozmairu guzika
        wyszukajPacjenta.setSize(250, 30);
        wyszukajPacjenta.setLocation(xStart, 20 + 20 + wys_guzika1);
        wyszukajPacjenta.setBorder(BorderFactory.createLineBorder(Color.blue));
        //-------------
        JTextField podaj_imie = new JTextField();
        JLabel imie = new JLabel("IMIE:");
        JTextField podaj_nazwisko = new JTextField();
        JLabel nazwisko = new JLabel("NAZWISKO:");
        JTextField podaj_pesel = new JTextField();
        JLabel pesel = new JLabel("PESEL:");

        imie.setSize(80, 20);
        nazwisko.setSize(80, 20);
        pesel.setSize(80, 20);
        podaj_imie.setSize(150, 20);
        podaj_nazwisko.setSize(150, 20);
        podaj_pesel.setSize(150, 20);

        int x = 20 + 20 + wys_guzika1 + wyszukajPacjenta.getSize().height + 20;
        imie.setLocation(xStart , x);
        nazwisko.setLocation(xStart , x +20);
        pesel.setLocation(xStart , x + 40);
        podaj_imie.setLocation(xStart + 100, x);
        podaj_nazwisko.setLocation(xStart + 100, x + 20);
        podaj_pesel.setLocation(xStart + 100, x + 40);

        mainFrame.add(podaj_imie);
        mainFrame.add(podaj_nazwisko);
        mainFrame.add(podaj_pesel);
        mainFrame.add(imie);
        mainFrame.add(nazwisko);
        mainFrame.add(pesel);
        //---------------------------
        JRadioButton zmarl = new JRadioButton("Zmarl");
        JRadioButton wyzdrowial = new JRadioButton("Wyzdrowial");
        ButtonGroup stany = new ButtonGroup();
        stany.add(zmarl);
        stany.add(wyzdrowial);

        zmarl.setSize(100, 30);
        zmarl.setLocation(xStart, x + 70);
        wyzdrowial.setSize(100, 30);
        wyzdrowial.setLocation(xStart, x + 100);

        mainFrame.add(zmarl);
        mainFrame.add(wyzdrowial);

        JTextField podaj_date = new JTextField();
        JLabel data = new JLabel("AKT. DATA: ");
        data.setSize(80, 20);
        data.setLocation(xStart, x + 150);
        podaj_date.setSize(150, 20);
        podaj_date.setLocation(xStart + 100, x + 150);

        mainFrame.add(podaj_date);
        mainFrame.add(data);

        //---------------------------

        //co się stanie po wciśnięciu guzika "WYSZUKAJ"
        wyszukajPacjenta.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String imieText = podaj_imie.getText();
                String nazwiskoText = podaj_nazwisko.getText();
                String peselText = podaj_pesel.getText();
                String dataText = podaj_date.getText();

                if (wyzdrowial.isSelected()) {
                    try {
                        aktOzdrowialy(peselText, dataText);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    try {
                        aktZmarly(peselText, dataText);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        mainFrame.add(wyszukajPacjenta, BorderLayout.CENTER);

        //------------WRÓĆ
        JButton wroc = new JButton("WRÓĆ");
        wroc.setLocation(szer_okienka/12, wys_okienka*6/9+60);
        wroc.setSize(wroc.getPreferredSize());
        wroc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainFrame.dispose();
            }
        });
        mainFrame.add(wroc);

        //------------------obrazki
        JLabel ImageLabel = new JLabel(new ImageIcon("C:\\Users\\stale\\IdeaProjects\\ProjektPO\\src\\res\\koronatlo.jpg"));
        ImageLabel.setBounds(15,10,200,300);
        mainFrame.add(ImageLabel);

        JLabel ImageLabel2 = new JLabel(new ImageIcon("C:\\Users\\stale\\IdeaProjects\\ProjektPO\\src\\res\\koronatlo.jpg"));
        ImageLabel2.setBounds(szer_okienka - 230,10,200,300);
        mainFrame.add(ImageLabel2);

        //-------------
        mainFrame.setVisible(true);
    }

    String usunZZarazonych (String pesel) throws IOException {
        RandomAccessFile file = new RandomAccessFile("zarazeni.txt", "rw");
        String delete;
        String task = "";
        String pobraneDane = "";
        byte[] tasking;
        while ((delete = file.readLine()) != null) {
            if (delete.startsWith(pesel)) {
                pobraneDane = delete;
                continue;
            }
            task += delete + "\n";
        }
        //System.out.println(pobraneDane);
        BufferedWriter writer = new BufferedWriter(new FileWriter("zarazeni.txt"));
        writer.write(task);
        file.close();
        writer.close();
        return pobraneDane;
    }

    void aktOzdrowialy(String pesel, String data_akt) throws IOException {

       String pobraneDane =  usunZZarazonych(pesel);

        try{
            PrintWriter writer_o = new PrintWriter(new FileWriter("ozdrowiali.txt", true));
            pobraneDane = pobraneDane + "|" + data_akt;
            writer_o.println(pobraneDane);
            writer_o.close();
        }
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
    //----------------------------------------

    void aktZmarly(String pesel, String data_akt) throws IOException {

        String pobraneDane =  usunZZarazonych(pesel);
        try{
            PrintWriter writer_o = new PrintWriter(new FileWriter("zmarli.txt", true));
            pobraneDane = pobraneDane + "|" + data_akt;
            System.out.println(pobraneDane);
            writer_o.println(pobraneDane);
            writer_o.close();
        }
        catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
}
