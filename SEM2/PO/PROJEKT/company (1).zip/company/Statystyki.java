//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Statystyki {
    JFrame mainFrame;
    ArrayList<Pacjent> kolekcja;
    String op = "Statystyki zachorowań, uzdrowień i zgonów.";
    JLabel opis;
    JButton polska;
    JButton swiat;
    JButton wroc;
    JButton pom_opis;

    Statystyki(final ArrayList<Pacjent> kolekcja){
        mainFrame = new JFrame();
        mainFrame.setLayout(null);
        //Ustawienie głównego okienka zawsze w centrum
        //pobranie szerokości i wysokości ekranu użytkownika
        int szer_ekranu = Toolkit.getDefaultToolkit().getScreenSize().width;
        int wys_ekranu = Toolkit.getDefaultToolkit().getScreenSize().height;
        //ustawienie rozmiaru okienka głównego
        mainFrame.setSize(szer_ekranu/2, wys_ekranu*4/7);
        //ustalenie rozmiaru okienka głównego
        int szer_okienka = mainFrame.getSize().width;
        int wys_okienka = mainFrame.getSize().height;
        //ustawienie okienka głównego na ekranie
        mainFrame.setLocation((szer_ekranu-szer_okienka)/2, (wys_ekranu-wys_okienka)/2); //początkowo był this //zawsze na srodku
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.kolekcja = kolekcja;


        //--------------------------------------------------------------------------------------------------------
        //NAPIS GŁÓWNY

        pom_opis = new JButton(op);
        pom_opis.setSize(pom_opis.getPreferredSize());
        int wys_opis = pom_opis.getSize().height;
        int szer_opis = pom_opis.getSize().width;

        opis = new JLabel(op);
        int szer_label = (szer_okienka - szer_opis)/2;
        opis.setBounds((szer_okienka - szer_opis)/2, 30, szer_opis, wys_opis);
        opis.setSize(pom_opis.getPreferredSize());

        mainFrame.add(opis);
        //-------------------------------------------------------------------------------------------
        //POLSKA
        polska = new JButton("POLSKA");
        //ustawienie idealnego rozmairu guzika
        polska.setSize(polska.getPreferredSize());
        //pobranie wysokosci i szerokosci GUZIKA 1
        int szer_guzika1 = polska.getSize().width;
        int wys_guzika1 = polska.getSize().height;
        polska.setLocation((szer_okienka - szer_guzika1)/2, (wys_okienka - wys_guzika1)/4);
        //co się stanie po wciśnięciu guzika
        polska.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Polska p1;
                p1 = new Polska(kolekcja);
            }
        });
        //dodanie GUZIKA 1 do okienka głównego
        mainFrame.add(polska, BorderLayout.CENTER);
        //---------------------------------------------------------------------------------------------
        //ŚWIAT
        swiat = new JButton("SWIAT");
        //ustawienie idealnego rozmairu guzika
        swiat.setSize(swiat.getPreferredSize());
        //pobranie wysokosci i szerokosci GUZIKA 1
        int szer_guzika2 = swiat.getSize().width;
        int wys_guzika2 = swiat.getSize().height;
        swiat.setLocation((szer_okienka - szer_guzika2)/2, (wys_okienka - wys_guzika2)/4 + 50);
        //co się stanie po wciśnięciu guzika
        swiat.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Swiat s1;
                s1 = new Swiat(kolekcja);
            }
        });
        mainFrame.add(swiat, BorderLayout.CENTER);
        //------------WRÓĆ
        wroc = new JButton("WRÓĆ");
        wroc.setLocation(szer_okienka/12, wys_okienka*6/9+60);
        wroc.setSize(wroc.getPreferredSize());
        wroc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainFrame.dispose();
            }
        });
        mainFrame.add(wroc);

        mainFrame.setVisible(true);
    }}