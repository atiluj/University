//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.time.ZoneOffset;
import java.util.ArrayList;
import javax.swing.JLabel;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.*;
import java.awt.*;

public class DodajZarazonego {

    JFrame mainFrame;
    ArrayList<Pacjent> kolekcja;
    String pol1 = "WYPEŁNIJ DANE PACJENTA:";
    String pol2 = "DOKUMENTACJA MEDYCZNA:";
    JLabel polecenie1;
    JLabel polecenie2;
    JButton zapisz;
    JButton wroc;
    JButton pom_pol1;
    JButton pom_pol2;
    JTextField plecText;
    JLabel plecLabel;
    JTextField imieText, nazwiskoText, wiekText, peselText, data_urText, adres_zamText, data_zdiagText;
    JTextField lekarz_prowaText, miejsce_leczText, adres_pobytuText, przebieg_chorobyText;
    JLabel imieLabel, nazwiskoLabel, wiekLabel, peselLabel, data_urLabel, adres_zamLabel, data_zdiagLabel;
    JLabel lekarz_prowaLabel, miejsce_leczLabel, adres_pobytuLabel, przebieg_chorobyLabel;

    DodajZarazonego(final ArrayList<Pacjent> kolekcja){
        mainFrame = new JFrame();
        mainFrame.setLayout(null);
        //Ustawienie głównego okienka zawsze w centrum
        //pobranie szerokości i wysokości ekranu użytkownika
        int szer_ekranu = Toolkit.getDefaultToolkit().getScreenSize().width;
        int wys_ekranu = Toolkit.getDefaultToolkit().getScreenSize().height;
        //ustawienie rozmiaru okienka głównego
        mainFrame.setSize(szer_ekranu/2, wys_ekranu*4/7);
        //ustalenie rozmiaru okienka głównego
        int szer_okienka = mainFrame.getSize().width;
        int wys_okienka = mainFrame.getSize().height;
        //ustawienie okienka głównego na ekranie
        mainFrame.setLocation((szer_ekranu-szer_okienka)/2, (wys_ekranu-wys_okienka)/2); //początkowo był this //zawsze na srodku
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.kolekcja = kolekcja;

        //--------------------------------------------------------------------------------------------------------
        //NAPIS GŁÓWNY

        pom_pol1 = new JButton(pol1);
        pom_pol1.setSize(pom_pol1.getPreferredSize());
        int wys_pol = pom_pol1.getSize().height;
        int szer_pol = pom_pol1.getSize().width;

        polecenie1 = new JLabel(pol1);
        int szer_label = (szer_okienka - szer_pol)/2;
        polecenie1.setBounds(20, 20, szer_pol, wys_pol);
        polecenie1.setSize(pom_pol1.getPreferredSize());

        mainFrame.add(polecenie1);

        int odstep = 40;
        int wys = 60;
//-------------------IMIE
        imieLabel = new JLabel("IMIE ");
        imieLabel.setSize(imieLabel.getPreferredSize());
        imieLabel.setLocation(odstep,wys);
        imieText = new JTextField("");
        imieText.setBounds(150, wys, 140, 20);
        mainFrame.add(imieLabel);
//-------------------NAZWISKO
        nazwiskoLabel = new JLabel("NAZWISKO ");
        nazwiskoLabel.setSize(nazwiskoLabel.getPreferredSize());
        nazwiskoLabel.setLocation(odstep,wys + 30);
        nazwiskoText = new JTextField("");
        nazwiskoText.setBounds(150, wys + 30, 140, 20);
        mainFrame.add(nazwiskoLabel);
//-------------------PESEL
        peselLabel = new JLabel("PESEL ");
        peselLabel.setSize(peselLabel.getPreferredSize());
        peselLabel.setLocation(odstep,wys + 30*2);
        peselText = new JTextField("");
        peselText.setBounds(150, wys + 30*2, 140, 20);
        mainFrame.add(peselLabel);
//-------------------PLEC

//-----PLEC DO WPISANIA

        plecLabel = new JLabel("PŁEĆ ");
        plecLabel.setSize(plecLabel.getPreferredSize());
        plecLabel.setLocation(odstep,wys + 30*3);
        plecText = new JTextField("");
        plecText.setBounds(150, wys + 30*3, 140, 20);
        mainFrame.add(plecLabel);

//-------------------WIEK
        wiekLabel = new JLabel("WIEK ");
        wiekLabel.setSize(wiekLabel.getPreferredSize());
        wiekLabel.setLocation(odstep,wys + 30*4);
        wiekText = new JTextField("");
        wiekText.setBounds(150, wys + 30*4, 140, 20);
        mainFrame.add(wiekLabel);
//-------------------DATA URODZENIA
        data_urLabel = new JLabel("DATA UR. ");
        data_urLabel.setSize(data_urLabel.getPreferredSize());
        data_urLabel.setLocation(odstep,wys + 30*5);
        data_urText = new JTextField("");
        data_urText.setBounds(150, wys + 30*5, 140, 20);
        mainFrame.add(data_urLabel);
//-------------------ADRES ZAMIESZKANIA
        adres_zamLabel = new JLabel("ADRES ZAM. ");
        adres_zamLabel.setSize(adres_zamLabel.getPreferredSize());
        adres_zamLabel.setLocation(odstep,wys + 30*6);
        adres_zamText = new JTextField("");
        adres_zamText.setBounds(150, wys + 30*6, 140, 20);
        mainFrame.add(adres_zamLabel);
//--------------------PRZEBIEG CHOROBY
        pom_pol2 = new JButton(pol2);
        pom_pol2.setSize(pom_pol2.getPreferredSize());
        int wys_pol2 = pom_pol2.getSize().height;
        int szer_pol2 = pom_pol2.getSize().width;

        polecenie2 = new JLabel(pol2);
        //int szer_label2 = (szer_okienka - szer_pol)/2;
        polecenie2.setBounds(szer_okienka/2 , 116, szer_pol2, wys_pol2);
        polecenie2.setSize(pom_pol2.getPreferredSize());

        mainFrame.add(polecenie2);
//-------------------DATA DIAGNOZY
        int odstep2 = szer_okienka/2 ;
        int wys2 = 120;
        data_zdiagLabel = new JLabel("DATA DIAGNOZY ");
        data_zdiagLabel.setSize(data_zdiagLabel.getPreferredSize());
        data_zdiagLabel.setLocation(odstep2,wys2 + 30);
        data_zdiagText = new JTextField("");
        data_zdiagText.setBounds(odstep2 + 160, wys2 + 30, 140, 20);
        mainFrame.add(data_zdiagLabel);
//-------------------LEKARZ PROWADZĄCY
        lekarz_prowaLabel = new JLabel("LEKARZ PROWADZĄCY");
        lekarz_prowaLabel.setSize(lekarz_prowaLabel.getPreferredSize());
        lekarz_prowaLabel.setLocation(odstep2,wys2 + 30*2);
        lekarz_prowaText = new JTextField("");
        lekarz_prowaText.setBounds(odstep2 + 160, wys2 + 30*2, 140, 20);
        mainFrame.add(lekarz_prowaLabel);
//-------------------MIEJSCE LECZENIA
        miejsce_leczLabel = new JLabel("MIEJSCE LECZENIA ");
        miejsce_leczLabel.setSize(miejsce_leczLabel.getPreferredSize());
        miejsce_leczLabel.setLocation(odstep2,wys2 + 30*3);
        miejsce_leczText = new JTextField("");
        miejsce_leczText.setBounds(odstep2 + 160, wys2 + 30*3, 140, 20);
        mainFrame.add(miejsce_leczLabel);
//-------------------ADRSE POBYTU
        adres_pobytuLabel = new JLabel("ADRSE POBYTU ");
        adres_pobytuLabel.setSize(adres_pobytuLabel.getPreferredSize());
        adres_pobytuLabel.setLocation(odstep2,wys2 + 30*4);
        adres_pobytuText = new JTextField("");
        adres_pobytuText.setBounds(odstep2 + 160, wys2 + 30*4, 140, 20);
        mainFrame.add(adres_pobytuLabel);
//-------------------PRZEBIEG CHOROBY
        przebieg_chorobyLabel = new JLabel("PRZEBIEG CHOROBY ");
        przebieg_chorobyLabel.setSize(przebieg_chorobyLabel.getPreferredSize());
        przebieg_chorobyLabel.setLocation(180,wys2 + 30*5 + 10);
        przebieg_chorobyText = new JTextField("");
        przebieg_chorobyText.setBounds(odstep2 , wys2 + 30*5, 300, 100);
        mainFrame.add(przebieg_chorobyLabel);
//------------------obrazek

        JLabel ImageLabel = new JLabel(new ImageIcon("C:\\Users\\stale\\IdeaProjects\\ProjektPO\\src\\res\\profilowe.jpeg"));
        ImageLabel.setBounds(600,10,100,100);
        mainFrame.add(ImageLabel);

//------------ZAPISZ
        zapisz = new JButton("ZAPISZ");
        zapisz.setLocation(szer_okienka/12, wys_okienka*6/9+20);
        zapisz.setSize(zapisz.getPreferredSize());
        zapisz.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String strImie = imieText.getText();
                String strNazwisko = nazwiskoText.getText();
                String strPlec = plecText.getText();
                String strWiek = wiekText.getText();
                int intWiek = Integer.parseInt(strWiek);
                String strPesel = peselText.getText();
                String strData_ur = data_urText.getText();
                String strAdres_zam = adres_zamText.getText();
                String strData_zdiag = data_zdiagText.getText();
                String strLekarz_prowa = lekarz_prowaText.getText();
                String strMiejsce_lecz = miejsce_leczText.getText();
                String strAdres_pobytu = adres_pobytuText.getText();
                String strPrzebieg_choroby = przebieg_chorobyText.getText();

                Zarazony z = new Zarazony(strImie, strNazwisko, strPlec, intWiek ,strPesel, strData_ur, strAdres_zam, strData_zdiag, strLekarz_prowa, strMiejsce_lecz, strAdres_pobytu, strPrzebieg_choroby);
                kolekcja.add(z);

                try{
                    PrintWriter writer = new PrintWriter(new FileWriter("zarazeni.txt", true));
                    Zarazony.ZapiszDoPliku(z, writer);
                    writer.close();
                }
                catch (IOException e){
                    System.out.println(e.getMessage());
                }
                mainFrame.dispose();
            }
        });

        mainFrame.add(zapisz);
//------------WRÓĆ
        wroc = new JButton("WRÓĆ");
        wroc.setLocation(szer_okienka/12, wys_okienka*6/9+60);
        wroc.setSize(wroc.getPreferredSize());
        wroc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainFrame.dispose();
            }
        });
        mainFrame.add(wroc);


        mainFrame.add(imieText);
        mainFrame.add(nazwiskoText);
        mainFrame.add(plecText);
        mainFrame.add(wiekText);
        mainFrame.add(peselText);
        mainFrame.add(data_urText);
        mainFrame.add(adres_zamText);
        mainFrame.add(data_zdiagText);
        mainFrame.add(lekarz_prowaText);
        mainFrame.add(miejsce_leczText);
        mainFrame.add(adres_pobytuText);
        mainFrame.add(przebieg_chorobyText);
        mainFrame.add(zapisz);
        mainFrame.add(polecenie1);
        mainFrame.setVisible(true);
    }
}