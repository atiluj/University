//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;

public class SpisZarazonych {
    JFrame mainFrame;
    ArrayList<Zarazony> kolekcja;
    JButton wroc;
    JTable tablica_zarazonych;

    SpisZarazonych(final ArrayList<Pacjent> kolekcja) throws FileNotFoundException {
        mainFrame = new JFrame();
        mainFrame.setLayout(null);
        //Ustawienie głównego okienka zawsze w centrum
        //pobranie szerokości i wysokości ekranu użytkownika
        int szer_ekranu = Toolkit.getDefaultToolkit().getScreenSize().width;
        int wys_ekranu = Toolkit.getDefaultToolkit().getScreenSize().height;
        //ustawienie rozmiaru okienka głównego
        mainFrame.setSize(szer_ekranu / 2, wys_ekranu * 4 / 7);
        //ustalenie rozmiaru okienka głównego
        int szer_okienka = mainFrame.getSize().width;
        int wys_okienka = mainFrame.getSize().height;
        //ustawienie okienka głównego na ekranie
        mainFrame.setLocation((szer_ekranu - szer_okienka) / 2, (wys_ekranu - wys_okienka) / 2); //początkowo był this //zawsze na srodku
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //this.kolekcja = kolekcja;

        //--------------TABELA DANYCH -- ZARAZENI
        ArrayList <Zarazony> lista_zarazonych = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader("zarazeni.txt"));
        try {
            lista_zarazonych = Zarazony.OdczytajZPliku(reader);
            //reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String[] naglowki = {"PESEL" , "IMIE" , "NAZWISKO", "PLEC", "DATA DIAGNOZY"};
        String[][] dane = new String[lista_zarazonych.size()+1][5];
        dane[0][0] = "PESEL";
        dane[0][1] = "IMIE";
        dane[0][2] = "NAZWISKO";
        dane[0][3] = "PLEC";
        dane[0][4] = "DATA DIAGNOZY";

       for (int i=0; i<lista_zarazonych.size(); i++)
        {
            dane[i+1][0] = lista_zarazonych.get(i).getPesel();
            dane[i+1][1] = lista_zarazonych.get(i).getImie();
            dane[i+1][2] = lista_zarazonych.get(i).getNazwisko();
            dane[i+1][3] = lista_zarazonych.get(i).getPlec();
            dane[i+1][4] = lista_zarazonych.get(i).getDatDiag();
        }
        tablica_zarazonych = new JTable(dane,naglowki);
        tablica_zarazonych.setLocation(0,0);
        tablica_zarazonych.setSize(szer_okienka , wys_okienka - 160);
        JScrollPane sp =new JScrollPane(tablica_zarazonych);
        mainFrame.add(sp);
        mainFrame.add(tablica_zarazonych);


        //------------WRÓĆ
        wroc = new JButton("WRÓĆ");
        wroc.setLocation(szer_okienka / 12, wys_okienka * 6 / 9 + 60);
        wroc.setSize(wroc.getPreferredSize());
        wroc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainFrame.dispose();
            }
        });
        mainFrame.add(wroc);
        //------------

        mainFrame.setVisible(true);
    }
}


