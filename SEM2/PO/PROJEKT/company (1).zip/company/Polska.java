//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Polska {
    JFrame mainFrame;
    ArrayList<Pacjent> kolekcja;
    JButton wroc;
    JButton aktualnie;
    JTable statystyka_PL;

    Polska(final ArrayList<Pacjent> kolekcja){
        mainFrame = new JFrame();
        mainFrame.setLayout(null);
        //Ustawienie głównego okienka zawsze w centrum
        //pobranie szerokości i wysokości ekranu użytkownika
        int szer_ekranu = Toolkit.getDefaultToolkit().getScreenSize().width;
        int wys_ekranu = Toolkit.getDefaultToolkit().getScreenSize().height;
        //ustawienie rozmiaru okienka głównego
        mainFrame.setSize(szer_ekranu/2, wys_ekranu*4/7);
        //ustalenie rozmiaru okienka głównego
        int szer_okienka = mainFrame.getSize().width;
        int wys_okienka = mainFrame.getSize().height;
        //ustawienie okienka głównego na ekranie
        mainFrame.setLocation((szer_ekranu-szer_okienka)/2, (wys_ekranu-wys_okienka)/2); //początkowo był this //zawsze na srodku
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.kolekcja = kolekcja;

        //--------------TABELA DANYCH POLSKA
        String dane_pl[][]={{"DATA","ZACHOROWANIA","UZDROWIENIA", "ZGONY"},
                {"2020-03-04","1","0","0"},
                {"2020-03-10","22","0","0"},
                {"2020-03-12","47","0","1"},
                {"2020-03-29","224","0","4"},
                {"2020-04-08","357","0","29"},
                {"2020-04-14","268","0","18"},
                {"2020-04-19","525","0","13"},
                {"2020-04-27","285","0","27"},
                {"2020-05-01","228","0","7"},
                {"2020-05-10","345","0","15"},
                {"2020-05-12","556","0","27"},
                {"2020-05-16","241","0","8"},
                {"2020-05-22","472","0","10"},
                {"2020-05-29","333","0","13"},
                {"2020-05-31","219","0","3"},
                {"2020-06-04","361","0","2"},
                {"2020-06-08","599","0","9"},
                {"2020-06-10","282","0","23"},
                {"2020-06-12","376","0","7"},
                {"2020- - ","","",""}
        };
        String kolumna_pl[]={"DATA","ZACHOROWANIA","OZDROWIENIA", "ZGONY"};
        statystyka_PL = new JTable(dane_pl,kolumna_pl);
        statystyka_PL.setLocation(0,0);
        statystyka_PL.setSize(szer_okienka, wys_okienka - 120);
        JScrollPane sp =new JScrollPane(statystyka_PL);
        mainFrame.add(sp);
        mainFrame.add(statystyka_PL);
//----------AKTUALNE
        aktualnie = new JButton("AKTUALNIE");
        aktualnie.setLocation((szer_okienka*9)/12,wys_okienka*6/9+60);
        aktualnie.setSize(aktualnie.getPreferredSize());
        aktualnie.addActionListener(new ActionListener() { //po nacisnieciu
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Aktualnie a1;
                a1 = new Aktualnie(kolekcja);
            }
        });
        mainFrame.add(aktualnie);

        //------------WRÓĆ
        wroc = new JButton("WRÓĆ");
        wroc.setLocation(szer_okienka/12, wys_okienka*6/9+60);
        wroc.setSize(wroc.getPreferredSize());
        wroc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                mainFrame.dispose();
            }
        });
        mainFrame.add(wroc);
        mainFrame.setVisible(true);
    }}
