//projekt COVID-19 - Aleksandra Stępniewska (315337), Julita Osman (314323)
package com.company;

import java.io.*;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<Pacjent> f1 = new ArrayList<Pacjent>();

        Pacjent t1 = new Zarazony("Jan", "Kowlaski", "M", 62, "62090473892", "1958-09-04", "ul. Chmielna 10, 56-304 Koszalin, Polska","8","9","10","11","12");
        Pacjent t2 = new Zarazony("Zbigniew", "Komba", "M", 32, "88050573892", "1988-05-05", "ul. Wieczrona 1/12, 50-104 Poznań, Polska","8","9","10","11","12");
//        Pacjent t3 = new Zdrowy("Urszula", "Makowska", "K", 80, 40010104738, "1940-01-01", "ul. Pastorska 109, 14-305 Kołobrzego, Polska");
//        Pacjent t4 = new Zmarly("Wojciech", "Pech", "M", 55, 65091473892, "1965-09-14", "ul. Kręta 13/156, 18-334 Leszno, Polska");

        f1.add(t1);
        f1.add(t2);
//        f1.add(t3);
//        f1.add(t4);

        InterfejsGraficzny g = new InterfejsGraficzny(f1);
    }
}
